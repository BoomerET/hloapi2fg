// Sample client for accessing Hero Lab® Online Public API
// Copyright © 2020 LWD Technology, Inc. All rights reserved.

import * as signalR from '@aspnet/signalr'

//NOTE! The constants below need to be setup appropriately with your own details for testing.

const TOOL_NAME = ""
const USER_TOKEN = ""
const ELEMENT_TOKEN = ""

//NOTE! The constants below should not need to be changed.

const PROTOCOL = "https://"
const API_HOST = PROTOCOL + "api.herolab.online"
const SIGNALR_ROUTE = "/api-signalr"
const CALLBACK = "Callback"
const NOTIFY = "Hlo_Notify"

//NOTE! The variables below are setup dynamically during execution.

let connection = null
let accessToken = null
let signalrHost = null
let gameServer = null

main()

async function main() {
   //verify the necessary values are configured
   assert(!!TOOL_NAME, "Tool name not configured")
   assert(!!USER_TOKEN, "User token not configured")
   assert(!!ELEMENT_TOKEN, "Element token not configured")

   //acquire an access token for use from the public api
   await acquireAccessToken()

   //retrieve the url to connect to for signalr
   await determineHost()

   //set everything up and connect to signalr to receive notifications
   setup()
   await connect()

   //make some basic calls of increasing behavior to verify signalr communication is working
   await ping()
   await parrot()
   await authenticateParrot()

   //make a call that sends a notification message back to us
   //NOTE! Give the message a chance to be received before proceeding.
   await inform()
   setTimeout(async () => {
      //attach to the game server
      await attachServer()

      //subscribe to the element token
      await subscribeElement()

      //start waiting for notifications from HLO that are simply output as console messages
      console.log("Waiting for notifications. Press \"Space\" to exit...")

      //listen for key presses
      window.addEventListener("keyup", async (event) => {
         //ignore anything that isn't the space key
         //NOTE! This is important since browser shortcuts like F12 etc. will
         //      be delivered to the window, and we don't want to close in those
         //      cases.
         if (event.key !== " " && event.keyCode !== 32) {
           return;
         }
   
         //unsubscribe from everything
         await unsubscribeAll()
   
         //pause before exiting so any errors from unsubscribe can be read
         console.log("Exiting in 5 seconds...")
         setTimeout(() => {
           window.close()
         }, 5000)
       })
   }, 300)
}

async function acquireAccessToken() {
   //construct and submit a request to acquire an access token
   const route = "/v1/access/acquire-access-token"
   const request = {
      refreshToken: USER_TOKEN, 
      toolName: TOOL_NAME,
      callerId: 123
   }
   const response = await submitRequest(route, request)

   //extract the access token
   accessToken = response.accessToken
}

async function determineHost() {
   //construct the request to retrieve the host to contact for notifications
   const route = "/v1/access/identify-notification-server"
   const request = {
      accessToken: accessToken,
      elementToken: ELEMENT_TOKEN,
      callerId: 123
   }
   const response = await submitRequest(route, request)

   //extract the signalr host and game server
   signalrHost = response.host
   gameServer = response.gameServer
}

async function attachServer() {
   //construct the request to attach to the game server
   const route = "/v1/access/attach-game-server";
   const request = {
      accessToken: accessToken,
      gameServer: gameServer,
      callerId: 123
   }
   const response = await submitRequest(route, request)

   //there is nothing to do with the response - it's merely an acknowledgement
   assert(typeof response === 'object', 'attachServer response')
}

async function subscribeElement() {
   //construct the request to subscribe to the element token
   const route = "/v1/character/subscribe"
   const request = {
      accessToken: accessToken,
      elementToken: ELEMENT_TOKEN,
      baseline: 0,
      callerId: 123
   }
   const response = await submitRequest(route, request)

   //there is nothing to do with the response - it's merely an acknowledgement
   assert(typeof response === 'object', 'subscribeElement response')
}

async function unsubscribeAll() {
   //construct the request to unsubscribe from everything
   const route = "/v1/access/unsubscribe-all";
   const request = {
      accessToken: accessToken,
      gameServer: gameServer,
      callerId: 123
   }
   const response = await submitRequest(route, request)

   //there is nothing to do with the response - it's merely an acknowledgement
   assert(typeof response === 'object', 'unsubscribeAll response')
}

async function submitRequest(url, request) {
   //serialize the data to json for submission
   const json = JSON.stringify(request)

   //submit the request
   url = API_HOST + url
   const response = await fetch(url, { 
      method: 'POST', 
      headers: {
         'Content-Type': 'application/json'
      },
      body: json
   })

    //deserialize the response body into the proper object
    const responseBody = await response.json()

    //sanity check the results and return them
    assert(responseBody.severity === Severity.Success, "submitRequest response severity")
    assert(responseBody.result === Result.Success, "submitRequest response result")
    assert(responseBody.callerId === request.callerId, "submitRequest response callerId")

    return responseBody
}

/** Setup the connection to the signalr hub */
function setup() {
   //construct the connection to the signalr hub
   connection = new signalR.HubConnectionBuilder()
      .withUrl(`${PROTOCOL}${signalrHost}${SIGNALR_ROUTE}`, {
         //configure the access token into the authorization header
         accessTokenFactory: () => accessToken
      })
      //configure a modicum of logging for diagnostics
      .configureLogging(signalR.LogLevel.Debug)
      .build()
   
   //setup a handler for when the connection is closed
   connection.onclose(connectionClosed)
}

/** Whenever the connection is closed, reconnect a few seconds later */
function connectionClosed(error) {
   console.error(error)
   retryConnection()
}

function retryConnection(tryCount = 1) {
   //wait a random interval of a few seconds
   const seconds = Math.floor(Math.random()*3) + 1
   setTimeout(async () => {
      try {
         await connection.start()
      }
      catch (error) {
         console.error(error && error.message ? error.message : "Unknown error")

         if (tryCount >= 5) {
            console.error("Maximum connection retries reached. Access token may have expired or been invalidated. Reload your browser page to acquire a new one.")
         }
         else {
            tryCount++
            retryConnection(tryCount)
         }
      }
   }, seconds*1000)
}

/** Connect to the signalr hub */
async function connect() {
   //setup the callback notification methods that we recognize
   connection.on(CALLBACK, callback)
   connection.on(NOTIFY, notify)

   //connect to the hub
   try {
      await connection.start()
      console.log("Connected")
   }
   catch (error) {
      console.error(error && error.message ? error.message : "Unknown error")
   }
}

/** Field the basic basic callback from the signalr hub */
function callback(messages) {
   const received = `******** Received from server: ${messages[0]}`
   console.log(received)
}

/** Invoke a simple method through signalr */
async function ping() {
   try {
      await connection.invoke("ping")
      console.log("Ping")
   }
   catch (error) {
      console.error(error && error.message ? error.message : "Unknown error")
   }
}

/** Invoke a method through signalr that echoes the string we send back to us */
async function parrot() {
   try {
      const x = await connection.invoke("parrot", 666)
      console.log(`Parrot: ${x}`)
   }
   catch (error) {
      console.error(error && error.message ? error.message : "Unknown error")
   }
}

/** Invoke a signalr method that echoes back and require authentication */
async function authenticateParrot() {
   try {
      const x = await connection.invoke("authParrot", 666)
      console.log(`authParrot: ${x}`)
   }
   catch (error) {
      console.error(error && error.message ? error.message : "Unknown error")
   }
}

/** Invoke a signalr method that sends a message back to us via the specified callback */
async function inform() {
   try {
      const x = await connection.invoke("inform", CALLBACK, "the message")
      console.log(`Inform: ${x}`)
   }
   catch (error) {
      console.error(error && error.message ? error.message : "Unknown error")
   }
}

/** 
 * Field standard notifications from the signalr hub
 * NOTE! We should always receive two parameters - a type and a json object.
 */
function notify(notify, payload) {
   //validate the notification type
   assert(ApiNotify[notify] !== undefined, "Notification type not defined")

   //emit a separator and the type to introduce the notification
   console.log("--------------------")
   console.log(`Notification - Type: ${ApiNotify[notify]}`)

   //display the object json for consultation
   console.log("    %o", payload)
}

function assert(condition, message) {
   if (condition) return
   console.error(`Assertion failed: ${message}`)
}

const Severity = {
   Success: 1,
   Info: 50,
   Warning: 100,
   Error: 150
}

const Result = {
   Success: 0
}

const ApiNotify = {
   UserTokenRevoked: -999,
   [-999]: "UserTokenRevoked",
   ElementTokenRevoked: -86,
   [-86]: "ElementTokenRevoked",
   RetrievalError: -1,
   [-1]: "RetrievalError",
   ShutdownInitiated: 1,
   [1]:  "ShutdownInitiated",
   CharacterLoad: 10,
   [10]: "CharacterLoad",
   CharacterUpdate: 11,
   [11]: "CharacterUpdate",
   StageAppear: 101,
   [101]: "StageAppear",
   StageDisappear: 102,
   [102]: "StageDisappear",
   StageContention: 120,
   [120]: "StageContention"
}